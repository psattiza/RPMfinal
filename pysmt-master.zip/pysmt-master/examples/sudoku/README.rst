Sudoku
======

* `sudoku.py </examples/sudoku/sudoku.py>`_ : Solves the sudoku problem using a command line interface
* `gui.py </examples/sudoku/gui.py>`_ : A small GUI that embeds sudoku.py and allows a user-friendly intercation with the sudoku solver.
